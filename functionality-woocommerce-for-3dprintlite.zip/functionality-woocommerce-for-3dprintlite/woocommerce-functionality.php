<?php
/**
 * Plugin Name: Woocommerce Functionality for 3dPrintLite
 * Plugin URI: https://www.alonesolutions.com/3dpf/
 * Description: This plugin bundles together code to add woocommerce functionality to the basic version of the plugin 3dPrintLite, to save you money.
 * Version: 1.0
 * Author: Daniel Martinez
 * Author URI: https://alonesolutions.ca/
 */




add_shortcode( '3dpwf_add_to_cart', 'add_model_to_cart' );

//start of options page

add_action('admin_init', 'register_3dplwf_settings' );
add_action('admin_menu', 'add_3dplwf_page');

// Init plugin options to white list our options
function register_3dplwf_settings(){
    register_setting( '3dplwf_group', '3dplwf_product_id');
}

// Add menu page
function add_3dplwf_page() {

    add_menu_page(
        '3DPLWF', // page <title>Title</title>
        '3DPrint Lite WF', // menu link text
        'manage_options', // capability to access the page
        '3dplwf-options', // page URL slug
    	'render_page', // callback function /w content
		'dashicons-cart', // menu icon
		100 // priority
	);

	//add_options_page('3dPrint Lite Woocommerce Functionality', '3DPL WF Settings', 'manage_options', '3dplwf-options', 'render_page');
}

// Draw the menu page itself
function render_page() {
	?>
	<div class="wrap">
		<h2>3dPrint Lite Woocommerce Functionality</h2>
		<form method="POST" action="options.php">
			<?php settings_fields('3dplwf_group'); ?>
			<?php $options = get_option('3dplwf_product_id'); ?>
			<table class="form-table">
				<tr valign="top"><th scope="row">Product Id</th>
					<td><input type="number" name="3dplwf_product_id[product-id]" placeholder="Product Id" value="<?php echo $options['product-id']; ?>" /></td>
				</tr>
				<tr valign="top"><th scope="row">Model Name Prefix</th>
					<td><input type="text" name="3dplwf_product_id[prefix]" placeholder="Custom Model: " value="<?php echo $options['prefix']; ?>" /></td>
				</tr>

			</table>
			<p class="submit">
			<input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
			</p>
		</form>
	</div>
	<?php
}

//end of options page

//retrieve settings from settings page
$options = get_option("3dplwf_product_id");
$customProductId = $options['product-id'];


if (empty($options["prefix"])) {

    $modelPrefix = "Custom Model: ";

} else {

    $modelPrefix = $options["prefix"];

}


function add_model_to_cart () {

    //run javascript code to take a snapshot of the canvas
    //echo "<script src='/wp-content/plugins/functionality-woocommerce-for-3dprintlite/canvas-photo.js'></script>";
    session_start();
    echo "<script>document.onload=function(){console.log(document.getElementById('p3dlite-thumb').value);}</script>";

    global $woocommerce;
    global $customProductId;

    if (array_key_exists("p3dlite_estimated_price", $_POST)) {

        //carry on POST variables into SESSION global variables to apply on cart page
        $_SESSION["custom_price"] = $_POST["p3dlite_estimated_price"];
        $_SESSION["custom_image"] = "data:image/png;base64," . $_POST["p3dlite_thumb"];
        $full_model_name = $_POST["attribute_pa_p3dlite_model"];
        $real_model_name = explode("_", $full_model_name, 2);
        $_SESSION["custom_name"] = $real_model_name[1];
        $_SESSION["model_url"] = "/wp-content/uploads/p3d/" . $_POST["attribute_pa_p3dlite_model"];
        print_r($_SESSION);


        if ($woocommerce->cart->add_to_cart($customProductId)) {

            echo "<div style='background-color: #32bc20; display:inline-block; border: 2px solid green; border-radius: 5px; padding:7px; '>Your model was successfully added to cart</div>";

        } else {

            echo "<div style='background-color: #ff7c7c; display:inline-block; border: 2px solid #aa0000; border-radius: 5px; padding:7px; '>Your model could not be added to cart. Please try again or contact the admin of this website. </div>";

        }

    }

}


session_start();

//changes the default price to the price quoted by 3dPrint Lite
function add_custom_price( $cart_object ) {

    global $customProductId;

	foreach ( $cart_object->get_cart() as $hash => $value ) {
		if ($value["product_id"] == $customProductId) {
			$value['data']->set_price( $value["custom_price"] );
		}
	}
}

//changes default product name/title to the name of the 3d model as named in the 3d file
function cart_product_title( $title, $values, $cart_item_key ) {

    global $customProductId;
    global $modelPrefix;

	if ($values["product_id"] == $customProductId) {
		return '<a href="'. $values["model_url"] .'">' . $modelPrefix . $values["custom_name"].'</a>';
	} else {
		return $title;
	}
}

//gives the cart product a unique key to force them as separate products and adds the extra data needed to change other attributes such as name, image, url and price
function force_individual_cart_items_and_add_extra_data( $cart_item_data, $product_id ) {

    global $customProductId;

	if ($product_id == $customProductId) {
		$unique_cart_item_key = md5( microtime() . rand() );
		$_SESSION["unique_key"] = $unique_cart_item_key;
		$cart_item_data['unique_key'] = $unique_cart_item_key;

		$cart_item_data["custom_price"] = $_SESSION["custom_price"];

		$cart_item_data["custom_name"] = $_SESSION["custom_name"];

		$cart_item_data["custom_image"] = $_SESSION["custom_image"];

		$cart_item_data["model_url"] = $_SESSION["model_url"];
	}

	return $cart_item_data;

}


//changes the default product image to the image of the 3d model taken with the Javascript
function add_custom_product_image($product_get_image, $cart_item, $cart_item_key) {

    global $customProductId;

	if ($cart_item["product_id"] == $customProductId) {
 		$custom_image_to_insert = $cart_item["custom_image"];
		$img = '<img src="'. $custom_image_to_insert . '" >';
    	return $img;
	} else {
		return $product_get_image;
	}


}


//adds the custom data such as the model name, image and link as meta data to the order so that it can be displayed on the checkout completed page and the email receipt.
add_action( 'woocommerce_checkout_create_order_line_item', 'custom_checkout_create_order_line_item', 20, 4 );
function custom_checkout_create_order_line_item( $item, $cart_item_key, $values, $order ) {

    if( ! empty( $values['model_url'] ) ) {

		$item->update_meta_data( 'model_url', $values['model_url'] );

	}

	if( ! empty( $values['custom_name'] ) ) {

		$item->update_meta_data( 'custom_name', $values['custom_name'] );

	}


}

//hide the metadata values in the email by formatting them and removing them

add_filter( 'woocommerce_order_item_get_formatted_meta_data', 'unset_specific_order_item_meta_data', 10, 2);
function unset_specific_order_item_meta_data($formatted_meta, $item){
    // Only on emails notifications
    if( is_admin() || is_wc_endpoint_url() )
        return $formatted_meta;

    foreach( $formatted_meta as $key => $meta ){
        if( in_array( $meta->key, array('model_url', 'custom_name') ) )
            unset($formatted_meta[$key]);
    }
    return $formatted_meta;
}

//changes the product title to have the link of the 3d file, passed as a POST variable when add to cart button was pressed
add_filter( 'woocommerce_order_item_name', 'display_product_title_as_link', 10, 2 );
function display_product_title_as_link( $item_name, $item ) {

    global $customProductId;

	if ($item["product_id"] == $customProductId) {

		return "<a href='".$item["model_url"]."'>Custom Model: ". $item["custom_name"] . "</a>";

	} else {

		return $item_name;
	}

}

function change_request_quote_text() {

    $data="_e( 'Add to Cart', '3dprint-lite' );";
    $textToFind = "_e( 'Request a Quote', '3dprint-lite' );";
    $file = getcwd()."/wp-content/plugins/3dprint-lite/includes/3dprint-lite-frontend.php";
    $originalFileContent=file_get_contents($file);
    $newFileContent=str_replace($textToFind, $data, $originalFileContent);
    file_put_contents($file, $newFilecontent);
    // echo "original file: ";
    // echo htmlspecialchars($originalFileContent);
    // echo "<br><br>";
    // echo "New file: ";
    // echo htmlspecialchars($newFileContent);
}

//runs all actions and filters defined above
add_filter( 'woocommerce_add_cart_item_data', 'force_individual_cart_items_and_add_extra_data', 10, 2 );

add_filter( 'woocommerce_cart_item_name', 'cart_product_title', 20, 3);

add_action( 'woocommerce_before_calculate_totals', 'add_custom_price' );

add_filter( 'woocommerce_cart_item_thumbnail', 'add_custom_product_image', 10, 3 );

//change_request_quote_text();


 ?>

