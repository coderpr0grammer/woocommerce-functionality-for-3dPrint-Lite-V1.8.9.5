
setTimeout(function() {

   if (window.location.href == "https://alonesolutions.ca/custom-prints/") {

        var form = document.querySelector("form.variations_form");
        form.addEventListener("submit", function(e) {
        
            var img = document.getElementById("p3dlite-cv").toDataURL("image/png");
            document.getElementById("model_image").value = img;
            
        });

    } 
    
}, 1000);
